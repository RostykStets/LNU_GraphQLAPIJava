package ua.edu.lnu.stelmashchuk.netflix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NetflixDgsExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
