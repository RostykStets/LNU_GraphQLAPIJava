package ua.edu.lnu.stelmashchuk.ecommerce;

public record CartItem(Product product, int quantity) {
}