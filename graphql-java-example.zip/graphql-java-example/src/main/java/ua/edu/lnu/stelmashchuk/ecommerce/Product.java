package ua.edu.lnu.stelmashchuk.ecommerce;

public record Product(String id,
                      String name,
                      double price) {
}
