package ua.edu.lnu.stelmashchuk.spring_for_graphql_example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringForGraphqlExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringForGraphqlExampleApplication.class, args);
	}

}
