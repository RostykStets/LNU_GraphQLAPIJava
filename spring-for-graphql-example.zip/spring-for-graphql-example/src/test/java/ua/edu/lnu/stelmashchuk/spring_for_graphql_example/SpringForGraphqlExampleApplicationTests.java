package ua.edu.lnu.stelmashchuk.spring_for_graphql_example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringForGraphqlExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
